function calcularPesoIdeal(){
    var edad = document.getElementById("txt_edad").value;
    var peso_ideal = edad * 2 + 8 ;
    //Mostramos resultado
    document.getElementById("cnt_peso_ideal").innerHTML = "Peso ideal es <b>" + peso_ideal + "</b> kilos.";
}